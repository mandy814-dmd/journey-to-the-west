<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Echoes of Light</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<!-- Header Section -->
<header>
    <div class="logo">Name/logo</div>
    <nav>
        <a href="#home">Home</a>
        <a href="#contact">Contact Us</a>
    </nav>
</header>

<!-- Main Content Section -->
<main>
    <h1>Echoes of Light</h1>
    <p class="subtitle">The New Life of Shadow Theatre in the Digital Age</p>
    <div class="cta">
        <p>Scroll down to create your character!</p>
        <div class="arrow">⌄</div>
    </div>
</main>

<!-- Character Section -->
<section class="character-section">
    <a href="ui/dressupnew.html" class="character-link">
        <div class="character-container">
                <img src="img/whole%20body.jpg" alt="body show" class="character-image body">
            <p class="character-text">
                Create a shadow puppet to know your personality
            </p>
        </div>
    </a>
</section>

</body>
</html>