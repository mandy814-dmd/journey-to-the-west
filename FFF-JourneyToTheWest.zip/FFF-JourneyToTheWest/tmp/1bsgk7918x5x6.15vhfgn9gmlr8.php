<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= ($html_title) ?></title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <?php echo $this->render($content,NULL,get_defined_vars(),0); ?>


<footer>
  <p>&copy; 2025 Journey to the West</p>
</footer>
</body>
</html>