<!-- 
A very simple home page View template:
just contains a link to the form that we will
use for collecting data.
 -->

<h1><?= ($html_title) ?></h1>
<p>
    <a href="<?= ($BASE) ?>/simpleform">This will take you to the input form</a>
</p>

<p>
    <a href="<?= ($BASE) ?>/about">Read about this example</a>
</p>
