<?php

class DatabaseConnection
{
    static function connect() {
        return new DB\SQL(
            "mysql:host=localhost;port=3306;dbname=alisased_journeytothewest",
            "alisased_alisased",
            "*Alisaaim2009"
        );
    }

}