<?php
// ✅ Load Fat-Free Framework if not already initialized
global $f3;
if (!isset($f3)) {
    $home = '/home/alisased/public_html/fatfree/FFF-JourneyToTheWest';
    require_once $home . '/AboveWebRoot/autoload/fatfree-core-master/base.php';
    $f3 = \Base::instance();
}

// ✅ Debugging: Check if `$f3` is properly set
if (!$f3) {
    die("❌ ERROR: Fat-Free Framework is STILL NOT initialized.");
}

// ✅ Check if the database connection exists
if (!$f3->exists('DB')) {
    die("❌ ERROR: Database connection not set in Fat-Free Framework.");
}

// ✅ Define the SimpleController class
class SimpleController {
    private $mapper;

    public function __construct($table) {
        global $f3; // Ensure Fat-Free is accessible

        if (!$f3->exists('DB')) {
            die("❌ ERROR: Database connection not set in Fat-Free Framework.");
        }

        // ✅ Create a database mapper for the given table
        $this->mapper = new DB\SQL\Mapper($f3->get('DB'), $table);
    }

    public function putIntoDatabase($data) {
        // ✅ Debugging: Show what data is being received
        echo "📌 DEBUG: Data Received\n";
        print_r($data);

        // ✅ Store data in the database
        $this->mapper->email = $data["email"];
        $this->mapper->userid = $data["userid"];
        $this->mapper->save();

        echo "\n✅ SUCCESS: Data has been saved!";
    }
}
?>
