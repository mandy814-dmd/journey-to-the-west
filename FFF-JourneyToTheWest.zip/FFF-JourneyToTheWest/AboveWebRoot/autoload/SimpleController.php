<?php
// ✅ Correctly import `Mapper` from Fat-Free Framework
use DB\SQL\Mapper;

class SimpleController {
    private $mapper;

    public function __construct($table) {
        global $f3; // Ensure Fat-Free is accessible

        if (!$f3->exists('DB')) {
            die("❌ ERROR: Database connection not set in Fat-Free Framework.");
        }

        // ✅ Correct way to use `Mapper`
        $this->mapper = new Mapper($f3->get('DB'), $table);
    }
}if (!file_exists('/home/alisased/public_html/fatfree/FFF-JourneyToTheWest/AboveWebRoot/autoload/fatfree-core-master/db/sql/mapper.php')) {
    die("❌ ERROR: `mapper.php` FILE IS MISSING!");
} else {
    die("✅ SUCCESS: `mapper.php` FILE EXISTS!");
}