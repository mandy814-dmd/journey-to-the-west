# Security Policy

## Reporting a Vulnerability

In case you've found something that should be treated carefully, please report security issues to <ikkez0n3@gmail.com>
