<?php
echo "🔍 Debugging check_post.php<br>";
echo "GET Data: ";
print_r($_GET);
echo "<br>POST Data: ";
print_r($_POST);
?>