<?php
$home = '/home/'.get_current_user();
$f3 = require($home.'/AboveWebRoot/autoload/fatfree-core-master/base.php');

// autoload Controller class(es) and anything hidden above web root, e.g. DB stuff
$f3->set('AUTOLOAD','autoload/;'.$home.'/AboveWebRoot/autoload/');

$db = DatabaseConnection::connect(); // defined as autoloaded class in AboveWebRoot/autoload/
$f3->set('DB', $db);

$f3->set('DEBUG',3);		// set maximum debug level
$f3->set('UI','ui/');		// folder for View templates
//==============================================================================
// Simple Example URL application routings
$f3->route('GET /check_post.php', function($f3) {
    echo "Inside Fat-Free Route!<br>";
    echo "GET Data: ";
    print_r($_GET);
});
//home page (index.html) -- actually just shows form entry page with a different title
$f3->route('GET /',
    function ($f3)
    {
        $f3->set('html_title','Website Landing Page');
        $f3->set('content','../ui/landing-page.html');
        echo template::instance()->render('../ui/landing-page.html');
    }
);
//==============================================================================
// When using GET, provide a form for the user to upload an image via the file input type
$f3->route('GET /dressupnew',
    function($f3)
    {
        $f3->set('html_title','Dress Up Quiz');
        $f3->set('content','dressupnew.html');
        echo template::instance()->render('dressupnew.html');
    }
);

$f3->route('GET /homepage', function($f3) {
    session_start();
    $email = $_SESSION['email'] ?? 'Unknown';
    $userid = $_SESSION['userid'] ?? 'Unknown';

    // Print stored session data
    echo "<h3>✅ Debugging: GET Route is Running</h3>";
    echo "User ID: " . $f3->get('userid') . "<br>";
    echo "Email: " . $f3->get('email') . "<br>";

    // ✅ Render homepage with stored values
    echo template::instance()->render('ui/homepage.html');
});
//==============================================================================
// When using GET, provide a form for the user to upload an image via the file input type
$f3->route('POST /homepage', function($f3) {
    echo "<h3>✅ Debugging: POST Route is Running</h3>";

    // Get form data
    $email = $f3->get('POST.email');
    $userid = $f3->get('POST.userid');

    // Debugging: Print received data
    echo "<h3>✅ Received Data:</h3>";
    echo "Email: " . $email . "<br>";
    echo "User ID: " . $userid . "<br>";

    // Check if data exists before continuing
    if (empty($email) || empty($userid)) {
        die("❌ Error: Missing email or userid! Check your form.");
    }

    // Insert into database
    $controller = new SimpleController('user_data');
    $controller->putIntoDatabase([
        "email" => $email,
        "userid" => $userid
    ]);

    // ✅ Store user data in Fat-Free
    $f3->set('email', $email);
    $f3->set('userid', $userid);

    // 🔥 Print out what was set before rendering homepage
    echo "<h3>✅ Data Stored in F3:</h3>";
    echo "User ID: " . $f3->get('userid') . "<br>";
    echo "Email: " . $f3->get('email') . "<br>";

    // ✅ Render `homepage.html`
    echo template::instance()->render('ui/homepage.html');

    exit(); // Stop execution so we can see the debug output
});

$f3->route('GET /dressupnew', function($f3) {
    echo template::instance()->render('ui/dressupnew.html');
});

// Run Fat-Free Framework
$f3->run();


?>